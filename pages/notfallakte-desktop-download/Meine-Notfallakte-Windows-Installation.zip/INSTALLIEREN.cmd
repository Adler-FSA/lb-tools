@echo off
setlocal
cd /d "%~dp0"
echo Meine Notfallakte - Windows Installation
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installieren.ps1"
if errorlevel 1 (
  echo.
  echo Die Installation wurde mit einem Fehler beendet.
  echo Bitte fotografiere die rote Fehlermeldung.
  echo.
  pause
)
