﻿MEINE DIGITALE & FINANZIELLE NOTFALLAKTE – WINDOWS
==================================================

INSTALLATION
1. ZIP vollständig entpacken: Rechtsklick > "Alle extrahieren".
2. Erst im entpackten Ordner "INSTALLIEREN.cmd" öffnen.
3. Die Einrichtung benötigt einmalig Internet.
4. Danach wird "Meine Notfallakte" auf dem Desktop angelegt.

WICHTIG
Die aktuelle Entwicklungsfassung ist noch nicht digital signiert.
Windows kann deshalb "Unbekannter Herausgeber" anzeigen.
Die spätere öffentliche Käuferfassung soll digital signiert werden.

Nach der Einrichtung arbeitet die Anwendung lokal und unabhängig von
Edge, Chrome und Firefox. JSON bleibt die externe Master-Sicherung.
