﻿$ErrorActionPreference = "Stop"

$AppName = "Meine Notfallakte"
$ElectronVersion = "43.2.0"
$InstallRoot = Join-Path $env:LOCALAPPDATA "FSA\NotfallakteDesktop"
$TempRoot = Join-Path $env:TEMP "FSA-Notfallakte-Setup"
$ElectronZip = Join-Path $TempRoot "electron.zip"
$ElectronDir = Join-Path $InstallRoot "runtime"
$AppDir = Join-Path $ElectronDir "resources\app"

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  Meine Notfallakte - Windows Desktop" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Diese Einrichtung benötigt einmalig Internet."
Write-Host "Danach arbeitet die Anwendung lokal und unabhängig vom Browser."
Write-Host ""

New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null

$ElectronUrl = "https://github.com/electron/electron/releases/download/v$ElectronVersion/electron-v$ElectronVersion-win32-x64.zip"
Write-Host "1/4 Desktop-Laufzeit wird aus der offiziellen Electron-GitHub-Quelle geladen ..."
Invoke-WebRequest -Uri $ElectronUrl -OutFile $ElectronZip -UseBasicParsing

if (Test-Path $ElectronDir) { Remove-Item $ElectronDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $ElectronDir | Out-Null
Expand-Archive -Path $ElectronZip -DestinationPath $ElectronDir -Force
New-Item -ItemType Directory -Force -Path $AppDir | Out-Null

$Base = "https://raw.githubusercontent.com/Adler-FSA/lb-tools/main/pages/notfallakte-offline-installation"
$Files = @(
    "index.html",
    "demo-stress-test.js",
    "pdf-core.js",
    "pdf-core-canonical.js",
    "pdf-document-export-v3.js",
    "pdf-document-export.js",
    "pdf-pagination-v08.js",
    "v08-final.js"
)

Write-Host "2/4 Notfallakten-Programmdateien werden lokal eingerichtet ..."
foreach ($File in $Files) {
    $Target = Join-Path $AppDir $File
    Write-Host "    $File"
    Invoke-WebRequest -Uri "$Base/$File" -OutFile $Target -UseBasicParsing
    if (!(Test-Path $Target) -or ((Get-Item $Target).Length -lt 10)) {
        throw "Programmdatei konnte nicht korrekt geladen werden: $File"
    }
}

$PackageJson = @'
{
  "name": "fsa-notfallakte-desktop",
  "version": "0.2.0",
  "private": true,
  "main": "main.js"
}
'@
Set-Content -Path (Join-Path $AppDir "package.json") -Value $PackageJson -Encoding UTF8

$MainJs = @'
const { app, BrowserWindow, shell } = require("electron");
const path = require("path");

app.setName("Meine Notfallakte");
app.setPath("userData", path.join(app.getPath("appData"), "FSA-Notfallakte-Desktop"));

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 980,
    minWidth: 900,
    minHeight: 700,
    title: "Meine digitale & finanzielle Notfallakte",
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, "index.html"));
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
'@
Set-Content -Path (Join-Path $AppDir "main.js") -Value $MainJs -Encoding UTF8

$OriginalExe = Join-Path $ElectronDir "electron.exe"
$TargetExe = Join-Path $ElectronDir "Meine Notfallakte.exe"
if (Test-Path $TargetExe) { Remove-Item $TargetExe -Force }
Rename-Item -Path $OriginalExe -NewName "Meine Notfallakte.exe"

Write-Host "3/4 Desktop-Verknüpfung wird erstellt ..."
$Desktop = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $Desktop "Meine Notfallakte.lnk"
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $TargetExe
$Shortcut.WorkingDirectory = $ElectronDir
$Shortcut.Description = "Meine digitale & finanzielle Notfallakte"
$Shortcut.Save()

Write-Host "4/4 Einrichtung abgeschlossen." -ForegroundColor Green
Write-Host ""
Write-Host "Installationsordner: $InstallRoot"
Write-Host "Eigener Datenbereich: %APPDATA%\FSA-Notfallakte-Desktop"
Write-Host ""
Write-Host "Die Notfallakte wird jetzt gestartet."
Start-Process -FilePath $TargetExe
